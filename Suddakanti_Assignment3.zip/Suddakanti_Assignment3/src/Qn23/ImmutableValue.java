package Qn23;

   public class ImmutableValue {
	
	     private int value = 0;

	     public ImmutableValue(int value)
	     {
	          this.value = value;
	     }

	     public int getValue()
	     {
	          return value;
	     }
	}

	class ImmutableValueUser{
	  private ImmutableValue currentValue = null;//currentValue reference can be changed even after the referred underlying ImmutableValue object has been constructed.

	  public ImmutableValue getValue(){
	    return currentValue;
	  }

	  public void setValue(ImmutableValue newValue){
	    this.currentValue = newValue;
	  }

	}
