package SecondQn;

class A {
    protected void method()
    {
        System.out.println("Hello World");
    }
}

public class MethodOverriding extends A{


    public void method()
    {
        System.out.println("Hello World");
    }
 
    public static void main(String args[])
    {
    	MethodOverriding b = new MethodOverriding();
        b.method();
    }
}
