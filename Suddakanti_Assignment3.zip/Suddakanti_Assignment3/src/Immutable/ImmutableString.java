package Immutable;

public class ImmutableString {

	public static void main(String args[]){    
        String NewString = "Hello";    
        NewString.concat("World");  
        System.out.println(NewString);    
    }    
}    
