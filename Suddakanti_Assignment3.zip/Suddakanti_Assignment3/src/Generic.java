
public class Generic<T> {
	   private T t;

	   public void add(T t) {
	      this.t = t;
	   }

	   public T get() {
	      return t;
	   }
	   
	   public static void main(String[] args) {
		   Generic<Integer> integerGeneric = new Generic<Integer>();
		   Generic<String> stringGeneric = new Generic<String>();
		    
		      integerGeneric.add(new Integer(10));
		      stringGeneric.add(new String("Hello World"));

		      System.out.printf("Integer Value :%d\n\n", integerGeneric.get());
		      System.out.printf("String Value :%s\n", stringGeneric.get());
		   }
}