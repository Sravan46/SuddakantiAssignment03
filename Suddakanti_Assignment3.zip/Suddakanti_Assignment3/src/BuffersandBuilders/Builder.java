package BuffersandBuilders;

public class Builder {

    public static void main(String args[])
    {
        StringBuilder str = new StringBuilder("Builder");
        str.append(" Class!");
        System.out.println(str);
    }
}