package BuffersandBuilders;

public class Buffer {

    public static void main(String args[])
    {
        StringBuffer str = new StringBuffer("Buffer");
        str.append(" Class!");
        System.out.println(str);
    }
}
