package SeventhQn;

public class Sample {
	   public static void main(String args[]){
	      int num;
	      final public Sample(){
	         num = 30;
	      }
	   }
	}