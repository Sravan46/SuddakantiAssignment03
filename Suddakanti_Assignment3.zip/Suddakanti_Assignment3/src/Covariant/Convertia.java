package Covariant;

class SuperClass {
	   SuperClass get() {
	      System.out.println("SuperClass");
	      return this;
	   }
	}

public class Convertia extends SuperClass {
	   
	Convertia get() {
	      System.out.println("Content");
	      return this;
	   }
	   public static void main(String[] args) {
	      SuperClass Convertia = new Convertia();
	      Convertia.get();
	   }
}