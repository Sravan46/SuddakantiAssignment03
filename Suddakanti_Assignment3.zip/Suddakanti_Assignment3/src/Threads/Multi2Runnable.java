package Threads;

public class Multi2Runnable implements Runnable{  
	public void run(){  
		System.out.println("thread is running...");  
		}  
		  
		public static void main(String args[]){  
		Multi2Runnable m1=new Multi2Runnable();  
		Thread t1 =new Thread(m1);   // Using the constructor Thread(Runnable r)  
		t1.start();  
		 }  
		}  
