package PrivateMethod4thQn;

public class Car  {
	
	public static void main(String[] args) 
	{ 
	display(); 
	} 
	static void display() 
	  { 
	System.out.println(" i20 is my favourite car"); 
	  } 
	} 