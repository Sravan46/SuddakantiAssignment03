package StringandBuffer;

public class Stringclass {
	 public static void main(String args[]) {
	      String s = "STRING LOWER CASE";
 	      System.out.println(s.toLowerCase());
	   }
	}