package StringandBuffer;

public class StringBufferExample {

	public static void main(String args[]) {
		
		 StringBuffer sb = new StringBuffer("LOWER CASE");
	
	      sb.setCharAt(1,'A'); 
	      System.out.println(sb);
	   }
	}
