package EighthQn;

public class TryBlockWithoutCatch {
	   public static void main(String[] args) {
	      try {
	         System.out.println("Try Block");
	      } finally {
	         System.out.println("Finally Block");
	      }
	   }
	}