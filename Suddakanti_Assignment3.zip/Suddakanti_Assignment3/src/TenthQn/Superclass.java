package TenthQn;

class SubClass {
    void method()
    {
        System.out.println("SuperClass");
    }
}
class Superclass extends SubClass {
    void method() throws ArithmeticException
    {
        System.out.println("SubClass");
    }
    public static void main(String args[])
    {
    	SubClass s = new Superclass();
        s.method();
    }
}
