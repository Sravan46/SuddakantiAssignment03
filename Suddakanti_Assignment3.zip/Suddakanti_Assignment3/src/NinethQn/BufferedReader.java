package NinethQn;

public class BufferedReader {
	public static void main(String s[]) {
		  // note the order of opening the resources
		  try (ResourceDemo d = new ResourceDemo(); ResourceDemo1 d1 = new ResourceDemo1()) {
		   int x = 10 / 0;
		   d.show();
		   d1.show1();
		  } catch (ArithmeticException e) {
		   System.out.println(e);
		  }
		 }
		}

class ResourceDemo implements AutoCloseable {
	 void show() {
	  System.out.println("inside show");
	 }

	 public void close() {
	  System.out.println("close from resourcedemo");
	 }
	}


class ResourceDemo1 implements AutoCloseable {
	 void show1() {
	  System.out.println("inside show1");
	 }

	 public void close() {
	  System.out.println("close from resourcedemo1");
	 }
	}